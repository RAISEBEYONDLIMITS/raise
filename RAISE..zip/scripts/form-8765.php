<?php

require_once('FormProcessor.php');

$form = array(
    'subject' => 'New Form Submission',
    'email_message' => 'You have a new form submission',
    'success_redirect' => '',
    'sendIpAddress' => true,
    'email' => array(
    'from' => 'info@raisebeyondlimits.com',
    'to' => 'info@raisebeyondlimits.com'
    ),
    'fields' => array(
    'name' => array(
    'order' => 1,
    'type' => 'string',
    'label' => 'Name:',
    'required' => true,
    'errors' => array(
    'required' => 'Field \'Name:\' is required.'
    )
    ),
    'phone' => array(
    'order' => 2,
    'type' => 'tel',
    'label' => 'Phone:',
    'required' => true,
    'errors' => array(
    'required' => 'Field \'Phone:\' is required.'
    )
    ),
    'name-1' => array(
    'order' => 3,
    'type' => 'string',
    'label' => 'Company Name (if applicable):',
    'required' => true,
    'errors' => array(
    'required' => 'Field \'Company Name (if applicable):\' is required.'
    )
    ),
    'message' => array(
    'order' => 4,
    'type' => 'string',
    'label' => 'Message',
    'required' => true,
    'errors' => array(
    'required' => 'Field \'Message\' is required.'
    )
    ),
    'email' => array(
    'order' => 5,
    'type' => 'email',
    'label' => 'Email:',
    'required' => true,
    'errors' => array(
    'required' => 'Field \'Email:\' is required.'
    )
    ),
    )
    );

    $processor = new FormProcessor('');
    $processor->process($form);

    ?>